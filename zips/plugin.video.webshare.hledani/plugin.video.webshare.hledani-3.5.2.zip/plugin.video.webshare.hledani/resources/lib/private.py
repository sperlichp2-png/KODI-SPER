# Skrytá sekce „Údržba knihovny“ – zámek, PIN, párování s ovladačem v telefonu a filtr obsahu.
# Sdílí ji hlavní doplněk (main.py) i služba (service.py, odemknutí z telefonu).
#
# Stav odemčení je jen v paměti Kodi (vlastnost okna), takže restart Kodi sekci vždy zamkne.
# Odemknutí z telefonu: POST /unlock  ts=<unix čas>  sig=hex(HMAC-SHA256(párovací kód, "unlock:<ts>"))
import hashlib
import hmac
import re
import secrets
import time
import unicodedata

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = 'plugin.video.webshare.hledani'
SECTION_URL = 'plugin://%s/?action=maint' % ADDON_ID
LOCK_SECONDS = 30 * 60          # zamkne se po 30 minutách nečinnosti
# výchozí tajné heslo není v kódu čitelně (kód je veřejně na GitHubu) – jen jeho otisk
_DEFAULT_WORD_HASH = 'd45b7a1eb321ed6f009850d07770c547d324e9b7d48e9230f7308a517e4a2701'
MAX_PIN_FAILS = 5               # po 5 chybných PINech pauza 5 minut


def _win():
    return xbmcgui.Window(10000)


def _get(key):
    return xbmcaddon.Addon(ADDON_ID).getSetting(key)


def _put(key, value):
    xbmcaddon.Addon(ADDON_ID).setSetting(key, value)


# ---------- zámek ----------
def is_unlocked():
    until = _win().getProperty('mt_until')
    try:
        return bool(until) and float(until) > time.time()
    except ValueError:
        return False


def touch():
    """Odemkne / prodlouží odemčení o LOCK_SECONDS od teď."""
    _win().setProperty('mt_until', str(time.time() + LOCK_SECONDS))


def lock():
    _win().clearProperty('mt_until')


def open_section():
    xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % SECTION_URL)


# ---------- tajné heslo a PIN ----------
def secret_word():
    """Vlastní heslo, nebo '' = platí výchozí (to v kódu čitelně není)."""
    return _get('mt_word')


def is_secret_word(text):
    t = (text or '').strip().lower()
    own = secret_word()
    if own:
        return t == own.lower()
    return hashlib.sha256(('pvs-cinema:' + t).encode('utf-8')).hexdigest() == _DEFAULT_WORD_HASH


def set_secret_word(word):
    _put('mt_word', word.strip())


def _pin_hash(pin, salt):
    return hashlib.sha256((salt + ':' + pin).encode('utf-8')).hexdigest()


def has_pin():
    return ':' in _get('mt_pin')


def set_pin(pin):
    salt = secrets.token_hex(8)
    _put('mt_pin', salt + ':' + _pin_hash(pin, salt))


def check_pin(pin):
    try:
        salt, h = _get('mt_pin').split(':', 1)
    except ValueError:
        return False
    return hmac.compare_digest(_pin_hash(pin, salt), h)


def ask_new_pin():
    d = xbmcgui.Dialog()
    p1 = d.numeric(0, 'Nový PIN (4–8 číslic)', '', True)
    if not p1:
        return False
    if not (4 <= len(p1) <= 8):
        d.ok('PIN', 'PIN musí mít 4 až 8 číslic.')
        return False
    p2 = d.numeric(0, 'Zadej PIN znovu', '', True)
    if p1 != p2:
        d.ok('PIN', 'PINy se neshodují, nic se nezměnilo.')
        return False
    set_pin(p1)
    d.notification('PvS Cinema', 'PIN uložen', xbmcgui.NOTIFICATION_INFO, 3000, False)
    return True


def unlock_with_pin():
    """Po zadání tajného hesla: PIN (napoprvé jeho nastavení) → odemknout a otevřít sekci."""
    win = _win()
    blocked_until = float(win.getProperty('mt_block') or 0)
    if blocked_until > time.time():
        return
    if not has_pin():
        if not ask_new_pin():
            return
    else:
        pin = xbmcgui.Dialog().numeric(0, 'PIN', '', True)
        if not pin:
            return
        if not check_pin(pin):
            fails = int(win.getProperty('mt_fails') or 0) + 1
            win.setProperty('mt_fails', str(fails))
            if fails >= MAX_PIN_FAILS:
                win.setProperty('mt_block', str(time.time() + 300))
                win.setProperty('mt_fails', '0')
            return
    win.setProperty('mt_fails', '0')
    touch()
    open_section()


# ---------- párování s ovladačem v telefonu ----------
_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'   # bez 0/O a 1/I, ať se kód dobře opisuje


def new_pair_code():
    raw = ''.join(secrets.choice(_ALPHABET) for _ in range(12))
    code = '-'.join(raw[i:i + 4] for i in range(0, 12, 4))
    _put('mt_code', code)
    return code


def pair_code():
    return _get('mt_code') or new_pair_code()


def norm_code(code):
    return re.sub(r'[^A-Z0-9]', '', (code or '').upper())


def unlock_signature(code, ts):
    return hmac.new(norm_code(code).encode('ascii'), ('unlock:%d' % ts).encode('ascii'),
                    hashlib.sha256).hexdigest()


def verify_unlock(ts, sig):
    """Ověří podepsaný požadavek z telefonu. Vrátí (ok, zpráva)."""
    win = _win()
    if float(win.getProperty('mt_block') or 0) > time.time():
        return False, 'Zkus to za chvíli'
    try:
        ts = int(ts)
    except (TypeError, ValueError):
        return False, 'Neplatný požadavek'
    if abs(time.time() - ts) > 120:
        return False, 'Nesedí čas v telefonu a v televizi'
    last = int(win.getProperty('mt_last_ts') or 0)
    if ts <= last:
        return False, 'Neplatný požadavek'
    if not hmac.compare_digest(unlock_signature(pair_code(), ts), (sig or '').lower()):
        fails = int(win.getProperty('mt_sig_fails') or 0) + 1
        win.setProperty('mt_sig_fails', str(fails))
        if fails >= MAX_PIN_FAILS:
            win.setProperty('mt_block', str(time.time() + 300))
            win.setProperty('mt_sig_fails', '0')
        return False, 'Ovladač není spárovaný – zadej v něm znovu párovací kód'
    win.setProperty('mt_last_ts', str(ts))
    win.setProperty('mt_sig_fails', '0')
    touch()
    return True, 'Odemčeno'


# ---------- filtr: nikdy nic, co naznačuje nezletilé ----------
_BLOCK_TOKENS = {
    'underage', 'child', 'children', 'childs', 'kid', 'kids', 'kiddie', 'preteen', 'preteens', 'pubescent',
    'loli', 'lolita', 'lolicon', 'shota', 'shotacon', 'minor', 'minors', 'jailbait', 'pedo', 'pedophile',
    'paedo', 'cp', 'pthc', 'schoolgirl', 'schoolgirls', 'schoolboy', 'toddler', 'infant', 'baby', 'babies',
    'dite', 'deti', 'detsky', 'detske', 'nezletila', 'nezletily', 'nezletile', 'nezleti', 'nezletilec',
    'holcicka', 'holcicky', 'skolacka', 'skolacky', 'skolak', 'dcerka', 'malicka', 'mladistva', 'mladistvy',
}
_AGE_RX = re.compile(r'(?<!\d)(?:[1-9]|1[0-7])\s*(?:yo|y\s*o|yrs?|years?\s*old|let|leta|lety|letou|lety)\b')


def _norm(text):
    t = unicodedata.normalize('NFKD', (text or '').lower())
    return ''.join(c for c in t if not unicodedata.combining(c))


# ---------- explicitní obsah: v běžném hledání se nikdy neukáže ----------
_XXX_TOKENS = {
    'xxx', 'porn', 'porno', 'pornos', 'porns', 'pornstar', 'pornstars', 'pornhub', 'xvideos', 'xhamster',
    'milf', 'milfs', 'anal', 'blowjob', 'blowjobs', 'cumshot', 'creampie', 'gangbang', 'bukkake', 'hentai', 'onlyfans',
    'brazzers', 'bangbros', 'realitykings', 'fakehub', 'faketaxi', 'czechcasting', 'deepthroat', 'fisting', 'handjob',
    'erotika', 'eroticke', 'eroticky', 'erotik', 'pornografie', 'sexvideo', 'nudes', 'jav',
}
_XXX_PHRASES = ('czech casting', 'czech streets', 'czech hunter', 'czech massage', 'czech amateurs', 'fake taxi',
                'public agent', 'reality kings', 'naughty america', 'adult film', 'adult movie', 'sex tape')


def explicit(text):
    t = re.sub(r'[\W_]+', ' ', _norm(text)).strip()
    if set(t.split()) & _XXX_TOKENS:
        return True
    t = ' %s ' % t
    return any(' %s ' % p in t for p in _XXX_PHRASES)


def blocked(text):
    t = _norm(text)
    if set(re.split(r'[\W_]+', t)) & _BLOCK_TOKENS:
        return True
    return bool(_AGE_RX.search(t.replace('_', ' ').replace('.', ' ')))
